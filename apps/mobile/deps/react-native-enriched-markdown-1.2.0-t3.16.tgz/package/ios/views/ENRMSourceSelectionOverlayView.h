#pragma once

#import <TargetConditionals.h>

#if !TARGET_OS_OSX
#import <UIKit/UIKit.h>

@interface ENRMSourceSelectionOverlayView : UIView
@property (nonatomic, copy) NSArray<NSValue *> *rects;
@end
#endif
