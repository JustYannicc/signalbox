#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, MarkdownNodeType) {
  MarkdownNodeTypeDocument,
  MarkdownNodeTypeParagraph,
  MarkdownNodeTypeText,
  MarkdownNodeTypeLink,
  MarkdownNodeTypeHeading,
  MarkdownNodeTypeLineBreak,
  MarkdownNodeTypeStrong,
  MarkdownNodeTypeEmphasis,
  MarkdownNodeTypeStrikethrough,
  MarkdownNodeTypeUnderline,
  MarkdownNodeTypeCode,
  MarkdownNodeTypeImage,
  MarkdownNodeTypeBlockquote,
  MarkdownNodeTypeUnorderedList,
  MarkdownNodeTypeOrderedList,
  MarkdownNodeTypeListItem,
  MarkdownNodeTypeCodeBlock,
  MarkdownNodeTypeThematicBreak,
  MarkdownNodeTypeTable,
  MarkdownNodeTypeTableHead,
  MarkdownNodeTypeTableBody,
  MarkdownNodeTypeTableRow,
  MarkdownNodeTypeTableHeaderCell,
  MarkdownNodeTypeTableCell,
  MarkdownNodeTypeLatexMathInline,
  MarkdownNodeTypeLatexMathDisplay,
  MarkdownNodeTypeSpoiler,
  MarkdownNodeTypeSuperscript,
  MarkdownNodeTypeSubscript,
  MarkdownNodeTypeHighlight,
  MarkdownNodeTypeSoftBreak,
  MarkdownNodeTypeBlankLine,
  MarkdownNodeTypeAdmonition,
  MarkdownNodeTypeVideo
};

@class MarkdownSourceRun;

@interface MarkdownASTNode : NSObject

@property (nonatomic, assign) MarkdownNodeType type;
@property (nonatomic, strong) NSString *content;
@property (nonatomic, strong) NSMutableDictionary *attributes;
@property (nonatomic, strong) NSMutableArray<MarkdownASTNode *> *children;
/// UTF-16 source/render spans supplied by the core parser. Render offsets index `content`, except break nodes map
/// their emitted separator at render range 0..1 while their content stays empty.
@property (nonatomic, strong) NSMutableArray<MarkdownSourceRun *> *sourceRuns;

- (instancetype)initWithType:(MarkdownNodeType)type;
- (void)addChild:(MarkdownASTNode *)child;
- (void)setAttribute:(NSString *)key value:(NSString *)value;

@end

/// A parser-owned correspondence between one source span and one content span.
@interface MarkdownSourceRun : NSObject
@property (nonatomic, assign) NSInteger sourceStart;
@property (nonatomic, assign) NSInteger sourceEnd;
@property (nonatomic, assign) NSInteger renderStart;
@property (nonatomic, assign) NSInteger renderEnd;
@end

/// Returns the exact source interval covered by mapped descendants, or NO when none exist.
FOUNDATION_EXPORT BOOL ENRMSourceAnchorForNode(MarkdownASTNode *node, NSInteger *start, NSInteger *end);

/// Stable dictionary key used by source-local link pill labels.
FOUNDATION_EXPORT NSString *ENRMSourceAnchorKey(NSInteger start, NSInteger end);

/// A node type that md4c emits as a standalone block stacked vertically,
/// as opposed to an inline span.
BOOL ENRMIsTopLevelBlockType(MarkdownNodeType type);
