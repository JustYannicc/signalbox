#pragma once

#import "MarkdownASTNode.h"
#import <Foundation/Foundation.h>

@class NSLayoutManager;
@class NSTextContainer;
@class MarkdownASTNode;

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSAttributedStringKey const ENRMSourceRunAttributeName;
FOUNDATION_EXPORT NSAttributedStringKey const ENRMSourceAnchorAttributeName;

@interface ENRMSourceAnchor : NSObject
@property (nonatomic, assign) NSInteger sourceStart;
@property (nonatomic, assign) NSInteger sourceEnd;
@property (nonatomic, copy) NSString *label;
@end

@interface ENRMSourceSelectionDisplayLabel : NSObject
@property (nonatomic, assign) NSInteger sourceStart;
@property (nonatomic, assign) NSInteger sourceEnd;
@property (nonatomic, assign) NSInteger start;
@property (nonatomic, assign) NSInteger end;
@property (nonatomic, copy) NSString *text;
@end

@interface ENRMSourceSelectionRequest : NSObject
@property (nonatomic, assign) NSInteger version;
@property (nonatomic, copy) NSString *revision;
@property (nonatomic, copy) NSString *requestId;
@property (nonatomic, copy) NSString *sourceMarkdown;
@property (nonatomic, assign) BOOL sourceMarkdownMatches;
@property (nonatomic, assign, getter=isValid) BOOL valid;
@property (nonatomic, copy) NSArray<NSValue *> *ranges;
@property (nonatomic, copy) NSArray<ENRMSourceSelectionDisplayLabel *> *labels;
@end

/// One rendered source mapping. owner is the text, code or table container that knows its layout.
@interface ENRMSourceSelectionTarget : NSObject
@property (nonatomic, strong) NSAttributedString *attributedText;
@property (nonatomic, strong) id owner;
@property (nonatomic, assign) NSRange renderedRange;
@property (nonatomic, assign) NSInteger sourceStart;
@property (nonatomic, assign) NSInteger sourceEnd;
@property (nonatomic, assign) NSInteger tableRow;
@property (nonatomic, assign) NSInteger tableColumn;
@property (nonatomic, assign, getter=isPill) BOOL pill;
@property (nonatomic, copy) NSString *_Nullable pillLabel;
@end

/// Returns targets for parser-owned text spans and explicit link-pill anchors.
FOUNDATION_EXPORT NSArray<ENRMSourceSelectionTarget *> *ENRMSourceSelectionTargets(NSAttributedString *text, id owner);

/// Parses and validates the v1 request shape, including UTF-16 scalar boundaries and ordered ranges.
FOUNDATION_EXPORT ENRMSourceSelectionRequest *_Nullable ENRMParseSourceSelection(NSString *json,
                                                                                 NSString *sourceMarkdown);

/// Parses the source-local label envelope. Invalid or stale payloads produce an empty override map.
FOUNDATION_EXPORT NSDictionary<NSString *, NSString *> *ENRMSourceLinkPillOverrides(NSString *json, NSString *revision,
                                                                                    NSString *sourceMarkdown);

/// Resolves every source range and display-label anchor against the complete native mapping.
FOUNDATION_EXPORT BOOL
ENRMResolveSourceSelection(ENRMSourceSelectionRequest *request, NSArray<ENRMSourceSelectionTarget *> *targets,
                           NSArray<ENRMSourceSelectionTarget *> *_Nullable *_Nullable resolvedTargets);

/// TextKit glyph rectangles in text-container coordinates, offset by origin.
FOUNDATION_EXPORT NSArray<NSValue *> *ENRMGlyphRectsForRange(NSLayoutManager *layoutManager,
                                                             NSTextContainer *textContainer, NSRange characterRange,
                                                             CGPoint origin);

/// Source-run annotations for a leaf node's appended content. Empty synthetic runs are ignored.
FOUNDATION_EXPORT void ENRMApplySourceRuns(MarkdownASTNode *node, NSMutableAttributedString *output,
                                           NSUInteger outputStart);
/// Explicit separator runs may map one rendered unit while the AST node content stays empty.
FOUNDATION_EXPORT void ENRMApplySourceRunsWithRenderLength(MarkdownASTNode *node, NSMutableAttributedString *output,
                                                           NSUInteger outputStart, NSUInteger renderLength);
/// Trims a rendered prefix, retaining only linear source runs clipped to its end.
FOUNDATION_EXPORT void ENRMTrimSourceRunsToLength(NSMutableAttributedString *attributedText, NSUInteger length);

/// Calculates a horizontal content offset that brings a content-coordinate rect into viewport bounds.
FOUNDATION_EXPORT CGFloat ENRMHorizontalOffsetToRevealRect(CGRect rectInContent, CGRect viewportBounds,
                                                           CGFloat currentOffset, CGFloat minimumOffset,
                                                           CGFloat maximumOffset);

/// Source-local pill labels apply only when the complete original source reached the renderer.
FOUNDATION_EXPORT NSDictionary<NSString *, NSString *> *
ENRMSourceLinkPillContentForRenderedMarkdown(NSDictionary<NSString *, NSString *> *sourceContent,
                                             NSString *sourceMarkdown, NSString *renderedMarkdown);
/// Reused segments need recreation when their effective source-local pill labels change.
FOUNDATION_EXPORT BOOL ENRMSourceLinkPillContentDidChange(NSDictionary<NSString *, NSString *> *_Nullable previous,
                                                          NSDictionary<NSString *, NSString *> *current);

NS_ASSUME_NONNULL_END
