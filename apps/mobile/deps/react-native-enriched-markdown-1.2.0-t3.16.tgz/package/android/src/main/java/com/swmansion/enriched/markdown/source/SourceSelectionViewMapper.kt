package com.swmansion.enriched.markdown.source

import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.Spanned
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.TextView
import com.swmansion.enriched.markdown.spans.LinkPillSpan
import com.swmansion.enriched.markdown.spans.SourceLinkAnchorSpan
import com.swmansion.enriched.markdown.spans.SourceRunSpan
import java.util.IdentityHashMap
import kotlin.math.ceil
import kotlin.math.floor

internal sealed interface SourceSelectionGeometry {
  data object Pending : SourceSelectionGeometry

  data object Rejected : SourceSelectionGeometry

  data class Ready(val rects: List<RectF>) : SourceSelectionGeometry
}

private data class DisplayRun(
  val view: TextView,
  val sourceStart: Int,
  val sourceEnd: Int,
  val displayStart: Int,
  val displayEnd: Int,
)

private data class DisplayAnchor(
  val view: TextView,
  val sourceStart: Int,
  val sourceEnd: Int,
  val displayStart: Int,
  val displayEnd: Int,
  val displayLabel: String?,
)

internal fun resolveSourceSelectionGeometry(
  root: ViewGroup,
  markdown: String,
  expectedRevision: String?,
  payload: SourceSelectionPayload,
): SourceSelectionGeometry {
  if (expectedRevision.isNullOrEmpty() || !payload.isValidFor(markdown, expectedRevision)) {
    return SourceSelectionGeometry.Rejected
  }

  val runs = ArrayList<DisplayRun>()
  val anchors = ArrayList<DisplayAnchor>()
  val textViews = ArrayList<TextView>()
  collectViews(root, textViews)
  textViews.forEach { view ->
    val text = view.text as? Spanned ?: return@forEach
    text.getSpans(0, text.length, SourceRunSpan::class.java).forEach { span ->
      val run = span.sourceRun
      val start = text.getSpanStart(span)
      val end = text.getSpanEnd(span)
      if (start >= 0 && end > start) {
        runs += DisplayRun(view, run.sourceStart, run.sourceEnd, start, end)
      }
    }
    text.getSpans(0, text.length, SourceLinkAnchorSpan::class.java).forEach { span ->
      val start = text.getSpanStart(span)
      val end = text.getSpanEnd(span)
      if (start >= 0 && end > start) {
        anchors += DisplayAnchor(view, span.sourceStart, span.sourceEnd, start, end, span.displayLabel)
      }
    }
  }

  val targets = ArrayList<DisplayTarget<TextView>>()
  for (range in payload.ranges.orEmpty()) {
    val mapped = mapRange(range, runs, markdown) ?: return SourceSelectionGeometry.Rejected
    targets += mapped
  }
  for (label in payload.labels.orEmpty()) {
    val matchingAnchors = anchors.filter { it.sourceStart == label.sourceStart && it.sourceEnd == label.sourceEnd }
    if (matchingAnchors.size != 1 || matchingAnchors.single().displayLabel != label.text) return SourceSelectionGeometry.Rejected
    // A pill is one visual attachment. Even a partial match highlights and reveals its full box.
    val anchor = matchingAnchors.single()
    if (label.end > label.text.length || !isScalarBoundary(label.text, label.start) || !isScalarBoundary(label.text, label.end)) {
      return SourceSelectionGeometry.Rejected
    }
    targets += DisplayTarget(anchor.view, anchor.displayStart, anchor.displayEnd)
  }

  if (targets.isEmpty()) return SourceSelectionGeometry.Rejected
  val uniqueTargets = deduplicateVisualTargets(targets) ?: return SourceSelectionGeometry.Rejected
  val coalesced = coalesceTargets(uniqueTargets)
  val localRects = ArrayList<Pair<TextView, Rect>>()
  for (target in coalesced) {
    val layout = target.view.layout ?: return SourceSelectionGeometry.Pending
    val text = target.view.text ?: return SourceSelectionGeometry.Pending
    if (target.start < 0 || target.end > text.length || target.end <= target.start) return SourceSelectionGeometry.Rejected
    val lineRects = glyphRects(target.view, layout, target.start, target.end)
    if (lineRects.isEmpty()) return SourceSelectionGeometry.Rejected
    for (localRect in lineRects) {
      revealHorizontalAncestors(root, target.view, localRect)
      localRects += target.view to localRect
    }
  }

  val rects = ArrayList<RectF>()
  for ((view, localRect) in localRects) {
    val viewScreenOrigin = IntArray(2)
    val rootScreenOrigin = IntArray(2)
    view.getLocationOnScreen(viewScreenOrigin)
    root.getLocationOnScreen(rootScreenOrigin)
    // Screen origins include ancestor translations such as a centered table's grid offset.
    val rootRectCoordinates =
      rootRelativeRect(
        SourceRect(localRect.left, localRect.top, localRect.right, localRect.bottom),
        SourcePoint(viewScreenOrigin[0], viewScreenOrigin[1]),
        SourcePoint(rootScreenOrigin[0], rootScreenOrigin[1]),
      )
    val rootRect = Rect(rootRectCoordinates.left, rootRectCoordinates.top, rootRectCoordinates.right, rootRectCoordinates.bottom)
    if (rootRect.width() <= 0 || rootRect.height() <= 0) return SourceSelectionGeometry.Rejected
    val visibleRect = clipToHorizontalAncestors(root, view, rootRect) ?: return SourceSelectionGeometry.Rejected
    if (visibleRect.width() <= 0 || visibleRect.height() <= 0) return SourceSelectionGeometry.Rejected
    rects += RectF(visibleRect)
  }

  return SourceSelectionGeometry.Ready(coalesceRects(rects))
}

private fun mapRange(
  range: SourceRange,
  runs: List<DisplayRun>,
  markdown: String,
): List<DisplayTarget<TextView>>? {
  val intersecting = runs.filter { it.sourceStart < range.end && it.sourceEnd > range.start }
    .sortedWith(compareBy(DisplayRun::sourceStart, DisplayRun::sourceEnd, DisplayRun::displayStart))
  if (intersecting.isEmpty()) return null
  if (intersecting.any { run ->
      run.sourceStart < 0 || run.sourceEnd <= run.sourceStart || run.displayEnd <= run.displayStart ||
        run.sourceEnd > markdown.length || !isScalarBoundary(markdown, run.sourceStart) ||
        !isScalarBoundary(markdown, run.sourceEnd)
    }
  ) return null
  val projections =
    projectSourceRange(
      range,
      intersecting.map { run ->
        SourceProjectionRun(run.sourceStart, run.sourceEnd, run.displayStart, run.displayEnd)
      },
    ) ?: return null
  val targets = ArrayList<DisplayTarget<TextView>>(projections.size)
  for (projection in projections) {
    val matches = intersecting.filter { run ->
      if (run.sourceStart > projection.sourceStart || run.sourceEnd < projection.sourceEnd) return@filter false
      val sourceLength = run.sourceEnd - run.sourceStart
      val displayLength = run.displayEnd - run.displayStart
      val displayStart =
        if (sourceLength == displayLength) run.displayStart + (projection.sourceStart - run.sourceStart) else run.displayStart
      val displayEnd =
        if (sourceLength == displayLength) run.displayStart + (projection.sourceEnd - run.sourceStart) else run.displayEnd
      displayStart == projection.displayStart && displayEnd == projection.displayEnd
    }
    if (matches.size != 1) return null
    val run = matches.single()
    val displayStart = projection.displayStart
    val displayEnd = projection.displayEnd
    val text = run.view.text ?: return null
    if (!isScalarBoundary(markdown, projection.sourceStart) || !isScalarBoundary(markdown, projection.sourceEnd)) return null
    if (!isScalarBoundary(text, displayStart) || !isScalarBoundary(text, displayEnd)) return null
    val textSpanned = text as? Spanned
    val pills = textSpanned?.getSpans(displayStart, displayEnd, LinkPillSpan::class.java).orEmpty()
    if (textSpanned == null || pills.isEmpty()) {
      targets += DisplayTarget(run.view, displayStart, displayEnd)
    } else {
      pills.forEach { pill ->
        val pillStart = textSpanned.getSpanStart(pill)
        val pillEnd = textSpanned.getSpanEnd(pill)
        if (pillStart >= 0 && pillEnd > pillStart) targets += DisplayTarget(run.view, pillStart, pillEnd)
      }
    }
  }

  return targets
}

private fun glyphRects(
  view: TextView,
  layout: Layout,
  start: Int,
  end: Int,
): List<Rect> {
  val rects = ArrayList<Rect>()
  val firstLine = layout.getLineForOffset(start)
  val lastLine = layout.getLineForOffset((end - 1).coerceAtLeast(start))
  for (line in firstLine..lastLine) {
    val lineStart = maxOf(start, layout.getLineStart(line))
    val lineEnd = minOf(end, layout.getLineEnd(line))
    if (lineEnd <= lineStart) continue
    val path = Path()
    layout.getSelectionPath(lineStart, lineEnd, path)
    val bounds = RectF()
    path.computeBounds(bounds, true)
    if (bounds.isEmpty) continue
    // Layout paths use text coordinates; convert them to TextView-local coordinates here.
    val left = floor(bounds.left + view.totalPaddingLeft - view.scrollX).toInt()
    val top = floor(bounds.top + view.totalPaddingTop - view.scrollY).toInt()
    val right = ceil(bounds.right + view.totalPaddingLeft - view.scrollX).toInt()
    val bottom = ceil(bounds.bottom + view.totalPaddingTop - view.scrollY).toInt()
    if (right > left && bottom > top) rects += Rect(left, top, right, bottom)
  }
  return rects
}

private fun revealHorizontalAncestors(
  root: ViewGroup,
  descendant: View,
  localRect: Rect,
) {
  var parent = descendant.parent
  while (parent is ViewGroup) {
    if (parent is HorizontalScrollView) {
      val descendantLocation = IntArray(2)
      val parentLocation = IntArray(2)
      descendant.getLocationOnScreen(descendantLocation)
      parent.getLocationOnScreen(parentLocation)
      // Screen locations already include this scroll offset, so apply only the viewport delta.
      val left = descendantLocation[0] - parentLocation[0] + localRect.left
      val right = descendantLocation[0] - parentLocation[0] + localRect.right
      val leftBound = parent.paddingLeft
      val rightBound = (parent.width - parent.paddingRight).coerceAtLeast(leftBound)
      val delta = when {
        left < leftBound -> left - leftBound
        right > rightBound -> right - rightBound
        else -> 0
      }
      val targetX = (parent.scrollX + delta).coerceAtLeast(0)
      if (targetX != parent.scrollX) parent.scrollTo(targetX, parent.scrollY)
    }
    if (parent === root) break
    parent = parent.parent
  }
}

private fun clipToHorizontalAncestors(
  root: ViewGroup,
  descendant: View,
  rect: Rect,
): Rect? {
  val rootLocation = IntArray(2)
  root.getLocationOnScreen(rootLocation)
  var visible = Rect(rect)
  var parent = descendant.parent
  while (parent is ViewGroup) {
    if (parent is HorizontalScrollView) {
      val location = IntArray(2)
      parent.getLocationOnScreen(location)
      val viewport =
        Rect(
          location[0] - rootLocation[0] + parent.paddingLeft,
          location[1] - rootLocation[1] + parent.paddingTop,
          location[0] - rootLocation[0] + parent.width - parent.paddingRight,
          location[1] - rootLocation[1] + parent.height - parent.paddingBottom,
        )
      if (!visible.intersect(viewport)) return null
    }
    if (parent === root) break
    parent = parent.parent
  }
  return visible
}

private fun collectViews(
  root: View,
  textViews: MutableList<TextView>,
) {
  if (root is TextView) textViews += root
  if (root is ViewGroup) {
    for (index in 0 until root.childCount) collectViews(root.getChildAt(index), textViews)
  }
}

private fun coalesceTargets(targets: List<DisplayTarget<TextView>>): List<DisplayTarget<TextView>> {
  val result = ArrayList<DisplayTarget<TextView>>()
  val targetsByView = IdentityHashMap<TextView, MutableList<DisplayTarget<TextView>>>()
  targets.forEach { target ->
    targetsByView.getOrPut(target.view) { ArrayList() }.add(target)
  }
  targetsByView.forEach { (view, viewTargets) ->
    val sorted = viewTargets.sortedBy { it.start }
    for (target in sorted) {
      val previous = result.lastOrNull()?.takeIf { it.view === view && target.start <= it.end }
      if (previous == null) {
        result += target
      } else {
        result[result.lastIndex] = previous.copy(end = maxOf(previous.end, target.end))
      }
    }
  }
  return result
}

private fun coalesceRects(rects: List<RectF>): List<RectF> {
  val result = ArrayList<RectF>()
  rects.sortedWith(compareBy(RectF::top, RectF::left)).forEach { rect ->
    val previous = result.lastOrNull()
    if (previous != null && kotlin.math.abs(previous.top - rect.top) < 1f && rect.left <= previous.right + 1f) {
      previous.right = maxOf(previous.right, rect.right)
      previous.bottom = maxOf(previous.bottom, rect.bottom)
    } else {
      result += RectF(rect)
    }
  }
  return result
}
