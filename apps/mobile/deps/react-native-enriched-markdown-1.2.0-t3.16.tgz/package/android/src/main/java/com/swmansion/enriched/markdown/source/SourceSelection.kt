package com.swmansion.enriched.markdown.source

import org.json.JSONArray
import org.json.JSONObject
import com.swmansion.enriched.markdown.parser.MarkdownASTNode
import com.swmansion.enriched.markdown.parser.SourceAnchor
import com.swmansion.enriched.markdown.parser.sourceAnchor
import com.swmansion.enriched.markdown.renderer.SpanStyleCache
import com.swmansion.enriched.markdown.styles.StyleConfig

data class SourceRange(
  val start: Int,
  val end: Int,
)

data class DisplayLabelRange(
  val kind: String,
  val sourceStart: Int,
  val sourceEnd: Int,
  val text: String,
  val start: Int,
  val end: Int,
)

data class SourceSelectionPayload(
  val version: Int?,
  val revision: String?,
  val requestId: String?,
  val sourceMarkdown: String?,
  val ranges: List<SourceRange>?,
  val labels: List<DisplayLabelRange>?,
  val malformed: Boolean,
) {
  fun isValidFor(
    markdown: String,
    expectedRevision: String,
  ): Boolean =
    !malformed &&
      version == 1 &&
      !expectedRevision.isEmpty() &&
      revision == expectedRevision &&
      !requestId.isNullOrEmpty() &&
      sourceMarkdown == markdown &&
      ranges != null &&
      labels != null &&
      (ranges.isNotEmpty() || labels.isNotEmpty()) &&
      validRanges(markdown, ranges) &&
      validLabels(markdown, labels)
}

data class SourcePillLabel(
  val sourceStart: Int,
  val sourceEnd: Int,
  val label: String,
)

data class SourcePillLabelPayload(
  val version: Int?,
  val revision: String?,
  val sourceMarkdown: String?,
  val labels: List<SourcePillLabel>?,
  val malformed: Boolean,
) {
  fun isValidFor(
    markdown: String,
    expectedRevision: String,
  ): Boolean =
    !malformed &&
      version == 1 &&
      !expectedRevision.isEmpty() &&
      revision == expectedRevision &&
      sourceMarkdown == markdown &&
      labels != null &&
      labels.all { label ->
        label.label.isNotEmpty() &&
          label.sourceStart >= 0 &&
          label.sourceEnd > label.sourceStart &&
          label.sourceEnd <= markdown.length &&
          isScalarBoundary(markdown, label.sourceStart) &&
          isScalarBoundary(markdown, label.sourceEnd)
      } && labels.map { it.sourceStart to it.sourceEnd }.toSet().size == labels.size
}

data class SourceProjectionRun(
  val sourceStart: Int,
  val sourceEnd: Int,
  val displayStart: Int,
  val displayEnd: Int,
)

data class ProjectedSourceRange(
  val sourceStart: Int,
  val sourceEnd: Int,
  val displayStart: Int,
  val displayEnd: Int,
)

/** Projects a fully covered source interval into UTF-16 display intervals. */
fun projectSourceRange(
  range: SourceRange,
  runs: List<SourceProjectionRun>,
): List<ProjectedSourceRange>? {
  if (range.start < 0 || range.end <= range.start) return null
  val intersecting = runs.filter { it.sourceStart < range.end && it.sourceEnd > range.start }
    .sortedWith(compareBy(SourceProjectionRun::sourceStart, SourceProjectionRun::sourceEnd))
  if (intersecting.isEmpty()) return null

  val projected = ArrayList<ProjectedSourceRange>(intersecting.size)
  var cursor = range.start
  for (run in intersecting) {
    if (run.sourceStart < 0 || run.sourceEnd <= run.sourceStart || run.displayStart < 0 || run.displayEnd <= run.displayStart) return null
    val start = maxOf(range.start, run.sourceStart)
    val end = minOf(range.end, run.sourceEnd)
    if (start != cursor) return null
    val sourceLength = run.sourceEnd - run.sourceStart
    val displayLength = run.displayEnd - run.displayStart
    if (sourceLength == displayLength) {
      projected.add(
        ProjectedSourceRange(
          start,
          end,
          run.displayStart + (start - run.sourceStart),
          run.displayStart + (end - run.sourceStart),
        ),
      )
    } else {
      if (start != run.sourceStart || end != run.sourceEnd) return null
      projected.add(ProjectedSourceRange(start, end, run.displayStart, run.displayEnd))
    }
    cursor = end
  }
  return if (cursor == range.end) projected else null
}

fun parseSourceSelection(value: String?): SourceSelectionPayload? {
  if (value.isNullOrEmpty()) return null
  val json = value.parseObjectOrNull() ?: return SourceSelectionPayload(null, null, null, null, null, null, true)
  val ranges = json.array("ranges")?.let { array -> array.objectsOrNull { item ->
    val start = item.integer("start") ?: return@objectsOrNull null
    val end = item.integer("end") ?: return@objectsOrNull null
    SourceRange(start, end)
  } }
  val labelsArray = json.array("labels")
  val labels = labelsArray?.let { array -> array.objectsOrNull { item ->
    val kind = item.string("kind") ?: return@objectsOrNull null
    val sourceStart = item.integer("sourceStart") ?: return@objectsOrNull null
    val sourceEnd = item.integer("sourceEnd") ?: return@objectsOrNull null
    val text = item.string("text") ?: return@objectsOrNull null
    val start = item.integer("start") ?: return@objectsOrNull null
    val end = item.integer("end") ?: return@objectsOrNull null
    DisplayLabelRange(kind, sourceStart, sourceEnd, text, start, end)
  } }
  val requiredArraysValid = json.array("ranges") != null &&
    (!json.has("labels") || labelsArray != null)
  return SourceSelectionPayload(
    version = json.integer("version"),
    revision = json.string("revision"),
    requestId = json.string("requestId"),
    sourceMarkdown = json.string("sourceMarkdown"),
    ranges = ranges,
    labels = labels ?: emptyList(),
    malformed = !requiredArraysValid || ranges == null || (labelsArray != null && labels == null),
  )
}

fun parseSourcePillLabels(value: String?): SourcePillLabelPayload? {
  if (value.isNullOrEmpty()) return null
  val json = value.parseObjectOrNull() ?: return SourcePillLabelPayload(null, null, null, null, true)
  val labelsArray = json.array("labels")
  val labels = labelsArray?.objectsOrNull { item ->
    val sourceStart = item.integer("sourceStart") ?: return@objectsOrNull null
    val sourceEnd = item.integer("sourceEnd") ?: return@objectsOrNull null
    val label = item.string("label") ?: return@objectsOrNull null
    SourcePillLabel(sourceStart, sourceEnd, label)
  }
  return SourcePillLabelPayload(
    version = json.integer("version"),
    revision = json.string("revision"),
    sourceMarkdown = json.string("sourceMarkdown"),
    labels = labels,
    malformed = labelsArray == null || labels == null,
  )
}

fun resolveSourcePillLabels(
  ast: MarkdownASTNode,
  markdown: String,
  revision: String?,
  json: String?,
  style: StyleConfig,
): Map<SourceAnchor, String> {
  val payload = parseSourcePillLabels(json) ?: return emptyMap()
  if (!payload.isValidFor(markdown, revision.orEmpty())) return emptyMap()

  val links = mutableListOf<MarkdownASTNode>()
  fun collect(node: MarkdownASTNode) {
    if (node.type == MarkdownASTNode.NodeType.Link) links += node
    node.children.forEach(::collect)
  }
  collect(ast)
  val linksByAnchor = links.mapNotNull { link -> link.sourceAnchor()?.let { it to link } }.groupBy({ it.first }, { it.second })
  val styleCache = SpanStyleCache(style)
  val resolved = LinkedHashMap<SourceAnchor, String>()
  for (label in payload.labels.orEmpty()) {
    val anchor = SourceAnchor(label.sourceStart, label.sourceEnd)
    val matchingLinks = linksByAnchor[anchor].orEmpty()
    if (matchingLinks.size != 1) return emptyMap()
    val link = matchingLinks.single()
    val url = link.getAttribute("url") ?: return emptyMap()
    if (styleCache.resolvedVariantForUrl(url)?.pill == null) return emptyMap()
    resolved[anchor] = label.label
  }
  return resolved
}

fun validRanges(
  markdown: String,
  ranges: List<SourceRange>,
): Boolean {
  var previousEnd = -1
  for (range in ranges) {
    if (range.start < 0 || range.end <= range.start || range.end > markdown.length) return false
    if (range.start < previousEnd) return false
    if (!isScalarBoundary(markdown, range.start) || !isScalarBoundary(markdown, range.end)) return false
    previousEnd = range.end
  }
  return true
}

private fun validLabels(
  markdown: String,
  labels: List<DisplayLabelRange>,
): Boolean {
  val anchors = HashSet<Pair<Int, Int>>()
  for (label in labels) {
    if (label.kind != "link-label" || label.text.isEmpty()) return false
    if (label.sourceStart < 0 || label.sourceEnd <= label.sourceStart || label.sourceEnd > markdown.length) return false
    if (!isScalarBoundary(markdown, label.sourceStart) || !isScalarBoundary(markdown, label.sourceEnd)) return false
    if (label.start < 0 || label.end <= label.start || label.end > label.text.length) return false
    if (!isScalarBoundary(label.text, label.start) || !isScalarBoundary(label.text, label.end)) return false
    if (!anchors.add(label.sourceStart to label.sourceEnd)) return false
  }
  return true
}

/** UTF-16 offsets may split neither a source nor a rendered surrogate pair. */
fun isScalarBoundary(
  text: CharSequence,
  offset: Int,
): Boolean {
  if (offset < 0 || offset > text.length) return false
  return offset == 0 || offset == text.length ||
    !(text[offset - 1].isHighSurrogate() && text[offset].isLowSurrogate())
}

private fun String.parseObjectOrNull(): JSONObject? =
  try {
    JSONObject(this)
  } catch (_: Exception) {
    null
  }

private fun JSONObject.array(name: String): JSONArray? =
  opt(name) as? JSONArray

private fun JSONObject.string(name: String): String? =
  opt(name) as? String

private fun JSONObject.integer(name: String): Int? {
  val number = opt(name) as? Number ?: return null
  val value = number.toDouble()
  if (!value.isFinite() || value < Int.MIN_VALUE || value > Int.MAX_VALUE || value % 1.0 != 0.0) return null
  return value.toInt()
}

private fun <T> JSONArray.objectsOrNull(map: (JSONObject) -> T?): List<T>? {
  val values = ArrayList<T>(length())
  for (index in 0 until length()) {
    val item = opt(index) as? JSONObject ?: return null
    val mapped = map(item) ?: return null
    values.add(mapped)
  }
  return values
}

