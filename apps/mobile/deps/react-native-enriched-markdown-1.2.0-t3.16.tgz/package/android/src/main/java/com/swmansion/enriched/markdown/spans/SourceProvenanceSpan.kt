package com.swmansion.enriched.markdown.spans

import android.text.TextPaint
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.style.CharacterStyle
import android.text.style.UpdateAppearance
import com.swmansion.enriched.markdown.parser.SourceRun

/** Keeps an exact parser-owned mapping on the rendered characters it produced. */
class SourceRunSpan(
  val sourceRun: SourceRun,
) : CharacterStyle(), UpdateAppearance {
  override fun updateDrawState(tp: TextPaint) = Unit
}

/** Identifies a link's source label and the pill label actually resolved by Android. */
class SourceLinkAnchorSpan(
  val sourceStart: Int,
  val sourceEnd: Int,
  val displayLabel: String?,
) : CharacterStyle(), UpdateAppearance {
  override fun updateDrawState(tp: TextPaint) = Unit
}

fun SpannableStringBuilder.attachSourceRuns(
  runs: List<SourceRun>,
  renderedStart: Int,
  renderedLength: Int,
  sourceContentLength: Int = renderedLength,
) {
  runs.forEach { run ->
    if (run.sourceStart < 0 || run.sourceEnd <= run.sourceStart) return@forEach
    if (run.renderStart < 0 || run.renderEnd <= run.renderStart || run.renderEnd > sourceContentLength) return@forEach
    val start = renderedStart + run.renderStart
    val end = renderedStart + run.renderEnd
    if (start < renderedStart || end > renderedStart + renderedLength || end > length) return@forEach
    setSpan(SourceRunSpan(run), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
  }
}
