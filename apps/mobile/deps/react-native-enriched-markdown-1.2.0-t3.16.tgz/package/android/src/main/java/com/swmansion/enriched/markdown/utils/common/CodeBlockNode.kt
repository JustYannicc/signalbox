package com.swmansion.enriched.markdown.utils.common

import android.util.Log
import com.swmansion.enriched.markdown.parser.MarkdownASTNode
import com.swmansion.enriched.markdown.parser.SourceRun

/**
 * Shared code block node semantics, used by both markdown flavors so the
 * meaning of a CodeBlock AST node (its text, language, fence) is defined in
 * one place. Language display names come from the shared C++ core
 * (cpp/highlight/CodeBlockLanguages.hpp) so all platforms label fences
 * identically; when the native library is unavailable the raw fence string
 * is shown instead.
 */
object CodeBlockNode {
  init {
    try {
      System.loadLibrary("react_codegen_EnrichedMarkdownTextSpec")
    } catch (e: UnsatisfiedLinkError) {
      Log.e("CodeBlockNode", "Failed to load native library", e)
    }
  }

  private external fun nativeDisplayLanguageName(language: String): String?

  fun extractCode(node: MarkdownASTNode): String {
    return extractCodeWithSourceRuns(node).text
  }

  data class CodeWithSourceRuns(
    val text: String,
    val sourceRuns: List<SourceRun>,
  )

  fun extractCodeWithSourceRuns(node: MarkdownASTNode): CodeWithSourceRuns {
    val builder = StringBuilder()
    val sourceRuns = mutableListOf<SourceRun>()

    fun append(current: MarkdownASTNode) {
      val base = builder.length
      builder.append(current.content)
      current.sourceRuns.forEach { run ->
        sourceRuns += run.copy(renderStart = base + run.renderStart, renderEnd = base + run.renderEnd)
      }
      current.children.forEach { append(it) }
    }
    append(node)
    val trimmed = builder.toString().trimEnd('\n')
    val retainedRuns =
      sourceRuns.mapNotNull { run ->
        if (run.renderStart < 0 || run.renderEnd <= run.renderStart || run.renderStart >= trimmed.length) return@mapNotNull null
        if (run.renderEnd <= trimmed.length) return@mapNotNull run
        // extractCode trims the final newline. Clip merged identity runs with the same
        // UTF-16 delta; a transformed atomic run cannot be split safely.
        if (run.sourceEnd - run.sourceStart == run.renderEnd - run.renderStart) {
          val clippedLength = trimmed.length - run.renderStart
          if (clippedLength > 0) {
            run.copy(
              sourceEnd = run.sourceStart + clippedLength,
              renderEnd = trimmed.length,
            )
          } else {
            null
          }
        } else {
          null
        }
      }
    return CodeWithSourceRuns(trimmed, retainedRuns)
  }

  fun language(node: MarkdownASTNode): String? = node.getAttribute("language")?.takeIf { it.isNotEmpty() }

  fun fenceChar(node: MarkdownASTNode): String = node.getAttribute("fenceChar")?.takeIf { it.isNotEmpty() } ?: "`"

  fun fencedMarkdown(
    code: String,
    language: String?,
    fenceChar: String,
  ): String {
    val fence = fenceChar.repeat(3)
    return "$fence${language.orEmpty()}\n$code\n$fence"
  }

  fun displayLanguageName(language: String?): String {
    if (language.isNullOrEmpty()) return ""
    return try {
      nativeDisplayLanguageName(language)
    } catch (e: UnsatisfiedLinkError) {
      null
    } ?: language
  }
}
