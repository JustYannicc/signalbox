package com.swmansion.enriched.markdown.source

import java.util.IdentityHashMap

internal data class DisplayTarget<T : Any>(
  val view: T,
  val start: Int,
  val end: Int,
)

internal data class SourcePoint(
  val x: Int,
  val y: Int,
)

internal data class SourceRect(
  val left: Int,
  val top: Int,
  val right: Int,
  val bottom: Int,
)

/** Removes duplicate visual targets after parser-owned source coverage was validated. */
internal fun <T : Any> deduplicateVisualTargets(targets: List<DisplayTarget<T>>): List<DisplayTarget<T>>? {
  val rangesByOwner = IdentityHashMap<T, MutableMap<Int, Int>>()
  val result = ArrayList<DisplayTarget<T>>(targets.size)
  for (target in targets) {
    if (target.start < 0 || target.end <= target.start) return null
    val ranges = rangesByOwner.getOrPut(target.view) { HashMap() }
    val previousEnd = ranges[target.start]
    if (previousEnd == null) {
      ranges[target.start] = target.end
      result += target
    } else if (previousEnd != target.end) {
      return null
    }
  }
  return result
}

/** Maps a view-local rectangle to root-local coordinates using their screen origins. */
internal fun rootRelativeRect(
  localRect: SourceRect,
  viewScreenOrigin: SourcePoint,
  rootScreenOrigin: SourcePoint,
): SourceRect =
  SourceRect(
    left = localRect.left + viewScreenOrigin.x - rootScreenOrigin.x,
    top = localRect.top + viewScreenOrigin.y - rootScreenOrigin.y,
    right = localRect.right + viewScreenOrigin.x - rootScreenOrigin.x,
    bottom = localRect.bottom + viewScreenOrigin.y - rootScreenOrigin.y,
  )
